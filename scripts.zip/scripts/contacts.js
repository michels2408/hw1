function onJson(json) {
    console.log("Response ricevuta");
    console.log(json);

    for(let item in json){
        const contact = document.querySelector('#contacts');

        const c_block = document.createElement('div');
        contact.appendChild(c_block);
        c_block.classList.add('#contacts');

        const name = document.createElement('h1');
        const telephon = document.createElement('p');

        c_block.appendChild(name);
        c_block.appendChild(telephon);

        name.classList.add('name');
        telephon.classList.add('telephon');

        name.textContent = json[item].citta;
        telephon.textContent = "Telefono: " + json[item].telefono;
    }
}

function onResponse(response) {
    console.log("JSON ricevuto");
    return response.json();
}

fetch("fetch_contacts.php").then(onResponse).then(onJson);