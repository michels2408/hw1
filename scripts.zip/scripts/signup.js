function checkCF(event) {
    const input = event.currentTarget;

    if(strlen(input.value) != 16) {
        cf_warning = document.querySelector(".cf span");
        cf_warning.classList.remove("hidden");
    } else {
        cf_warning.classList.add("hidden");
    }

    if(input.value === "") {
        cf_warning.classList.add('hidden');
    }
}

function checkUsername(event) {
    const input = event.currentTarget;

    if(!/^[a-zA-Z0-9_-]{1,15}$/.test(input.value)) {
        un_warning = document.querySelector(".username span");
        un_warning.classList.remove("hidden");
    } else {
        un_warning.classList.add("hidden");
    }

    if(input.value === "") {
        un_warning.classList.add('hidden');
    }
}

function checkPassword(event) {
    const input = event.currentTarget;

    if(strlen(input.value) < 8 || strlen(input.value) > 15) {
        pw_warning = document.querySelector(".password span");
        pw_warning.classList.remove("hidden");
    } else {
        pw_warning.classList.add("hidden");
    }

    if(input.value === "") {
        pw_warning.classList.add('hidden');
    }
}

function checkConfirmPassword(event) {
    const input = event.currentTarget;
    const password = document.querySelector(".password input").value

    if(strcmp(input.value, password) != 0) {
        cpw_warning = document.querySelector(".confirm_password span");
        cpw_warning.classList.remove("hidden");
    } else {
        cpw_warning.classList.add("hidden");
    }

    if(input.value === "") {
        cpw_warning.classList.add('hidden');
    }
}

document.querySelector(".cf input").addEventListener("keyup", checkCF);
document.querySelector(".username input").addEventListener("keyup", checkUsername);
document.querySelector(".password input").addEventListener("keyup", checkPassword);
document.querySelector(".confirm_password input").addEventListener("keyup", checkConfirmPassword);

